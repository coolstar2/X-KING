const JsConfuser = require("js-confuser");
const {
    command,
} = require("../lib");
command(
  {
    pattern: "encrypt",
    fromMe: true,
    desc: "Encrypt JavaScript code",
    type: "utility",
  },
  async (king, match, m) => {
    const text = m?.quoted?.text?.trim();
    if (!text) return king.reply("*_Reply to a JavaScript code snippet to encrypt_*");

    // Send "Encrypting..." message
    await king.reply("Encrypting......🌀");

    try {
      // Perform obfuscation with corrected options
      const result = await JsConfuser.obfuscate(text, {
        target: "node",
        preset: "high",
        calculator: true,
        compact: true,
        hexadecimalNumbers: true,
        controlFlowFlattening: 0.75,
        deadCode: 0.2,
        dispatcher: true,
        duplicateLiteralsRemoval: 0.75,
        flatten: true,
        globalConcealing: true,
        identifierGenerator: "randomized",
        minify: true,
        movedDeclarations: true,
        objectExtraction: true,
        opaquePredicates: 0.75,
        renameVariables: true,
        renameGlobals: true,
        shuffle: { hash: 0.5, true: 0.5 },
        stringConcealing: true,
        stringCompression: true,
        stringEncoding: true,
        stringSplitting: 0.75,
        rgf: false,
      });

      // Check if the result contains obfuscated code
      const obfuscatedCode = result?.code || result;
      if (!obfuscatedCode || typeof obfuscatedCode !== "string") {
        throw new Error("Invalid obfuscation result.");
      }

      // Send the obfuscated code in a code block
      king.reply(obfuscatedCode);
    } catch (err) {
      king.reply("*Error during encryption:*\n" + err.message);
    }
  }
);